/*
 * main.c
 *
 *  Created on: 14 Feb 2013
 *      Author: Maxime Vincent
 * Description: Virtually the most simple demo that can be run on an ARM MCU.
 *              The target is barely running - all clocks are off, the core is
 *              just executing a few simple instructions.
 *
 *     Purpose: Purpose is to demonstrate an openocd-gdb setup to flash and 
 *              step through code on the target.
 *
 *     Context: Written in the context of the Embedded C course by TASS Belgium.
 */

/* Includes */ 
#include "stm32f4xx.h"
#include "main.h"

/* Defines */
#define EVER        (;;)

/* Prototypes */
int main(void);

void TIM2_IRQHandler(void);
void INTTIM_Config(void);

/* main C entry point */
int main(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    int i=0;

    /* RCC clock config */

    /*-------------------------- GPIO Configuration ----------------------------*/
    /* GPIOD Configuration: Pins 12, 13, 14 and 15 in output push-pull          */

    for EVER
    {
        i++;
    }
}

void TIM2_IRQHandler(void)
{
}

void INTTIM_Config(void)
{
}

