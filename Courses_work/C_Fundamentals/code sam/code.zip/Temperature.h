#ifndef Temperature
#define Temperature 

double CtoK(double celcius);
double CtoF(double celcius);
double KtoC(double kelvin);
double StringToDouble(const char *str);

#endif